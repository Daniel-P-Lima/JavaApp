import java.util.ArrayList;
import java.util.List;

public class Paciente {
    private String nome;
    private String cpf;

    public Paciente(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public static List<Paciente> criarPacientes(List<List<String>> dadosPacientes) {
        List<Paciente> pacientes = new ArrayList<>();
        for (List<String> linha : dadosPacientes) {
            if (linha.size() >= 2) { // Verifica se há pelo menos dois campos na linha
                String nome = linha.get(0);
                String cpf = linha.get(1);
                pacientes.add(new Paciente(nome, cpf));
            } else {
                System.out.println("Erro: Linha mal formatada no arquivo de pacientes.");
            }
        }
        return pacientes;
    }
}
