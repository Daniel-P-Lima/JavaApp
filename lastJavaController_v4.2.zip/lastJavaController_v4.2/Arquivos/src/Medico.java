import java.util.ArrayList;
import java.util.List;

public class Medico {
    private String nome;
    private String codigoUnico;

    public Medico(String nome, String codigoUnico) {
        this.nome = nome;
        this.codigoUnico = codigoUnico;
    }

    public String getNome() {
        return nome;
    }

    public String getCodigoUnico() {
        return codigoUnico;
    }

    public static List<Medico> criarMedicos(List<List<String>> dadosMedicos) {
        List<Medico> medicos = new ArrayList<>();
        for (List<String> linha : dadosMedicos) {
            medicos.add(new Medico(linha.get(0), linha.get(1)));
        }
        return medicos;
    }
}
