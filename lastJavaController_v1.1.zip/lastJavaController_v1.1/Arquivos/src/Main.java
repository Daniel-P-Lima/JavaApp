import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Main {
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    static boolean loop = true;
    static int entradaDoUsuario;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Scanner entradaDeUsuario = new Scanner(System.in);

        // Lendo os dados dos arquivos CSV de médicos, pacientes e consultas
        List<List<String>> dadosMedicos = LeituraMedicos.lerDados("Arquivos/medicos.csv");
        List<List<String>> dadosPacientes = LeituraPacientes.lerDados("Arquivos/pacientes.csv");
        List<List<String>> dadosConsultas = LeituraConsultas.lerDados("Arquivos/consultas.csv");

        // Criando lista de médicos
        List<Medico> medicos = Medico.criarMedicos(dadosMedicos);

        // Criando lista de pacientes
        List<Paciente> pacientes = Paciente.criarPacientes(dadosPacientes);

        // Criando lista de consultas
        List<Consulta> consultas = Consulta.criarConsultas(dadosConsultas, medicos, pacientes);

        List<String> informacoesOpcao = new ArrayList<>();


        while(loop == true) {
            System.out.println("1. Exibir os pacientes de um determinado médico: ");
            System.out.println("2. Buscar consultas agendadas de um médico agendada dentro de um período: ");
            System.out.println("3. Exibir médicos de um certo paciente: ");
            System.out.println("4. Todas as consultas de um determinado paciente com médicos: ");
            System.out.println("5. Consultas agendadas de um certo paciente: ");
            System.out.println("6. Pacientes de um médico sem consultas em um determinado período: ");
            entradaDoUsuario = entradaDeUsuario.nextInt();
            switch (entradaDoUsuario) {
                case 1:
                    //1. Exibindo os pacientes de um determinado médico
                    System.out.println("Digite o código único do médico para exibir os pacientes:");
                    String codigoMedico = scanner.nextLine();
                    Medico medico = encontrarMedicoPorCodigoUnico(medicos, codigoMedico);
                    if (medico != null) {
                        informacoesOpcao.add("Pacientes do Médico " + medico.getNome() + ":");
                        System.out.println("Pacientes do Médico " + medico.getNome() + ":");
                        List<Paciente> pacientesDoMedico = pacientesDoMedico(medico, consultas);
                        if (pacientesDoMedico.isEmpty()) {
                            informacoesOpcao.add("Este médico não possui consultas.");
                            System.out.println("Este médico não possui consultas.");
                        } else {
                            for (Paciente paciente : pacientesDoMedico) {
                                informacoesOpcao.add(paciente.getNome());
                                System.out.println(paciente.getNome());
                            }
                        }
                    } else {
                        System.out.println("Médico não encontrado.");
                    }
                    System.out.println("====================================================================");
                    break;
                case 2:
                    //2. Buscar consultas agendadas para um médico dentro de um período
                    System.out.println("Digite o código único do médico para buscar consultas no período:");
                    String codigoMedicoConsultaPeriodo = scanner.nextLine();
                    System.out.println("Digite a data inicial no formato dd/MM/yyyy:");
                    String dataInicialStr = scanner.nextLine();
                    System.out.println("Digite a data final no formato dd/MM/yyyy:");
                    String dataFinalStr = scanner.nextLine();

                    try {
                        Date dataInicial = sdf.parse(dataInicialStr);
                        Date dataFinal = sdf.parse(dataFinalStr);
                        Medico medicoDeConsultaPeriodo = encontrarMedicoPorCodigoUnico(medicos, codigoMedicoConsultaPeriodo);
                        if (medicoDeConsultaPeriodo != null) {
                            List<Consulta> consultasNoPeriodo = consultasDoMedicoNoPeriodo(medicoDeConsultaPeriodo, consultas, sdf, dataInicial, dataFinal);
                            if (!consultasNoPeriodo.isEmpty()) {
                                informacoesOpcao.add("Consultas do Médico " + medicoDeConsultaPeriodo.getNome() + " no período de " + dataInicialStr + " a " + dataFinalStr + ":");
                                System.out.println("Consultas do Médico " + medicoDeConsultaPeriodo.getNome() + " no período de " + dataInicialStr + " a " + dataFinalStr + ":");
                                for (Consulta consulta : consultasNoPeriodo) {
                                    informacoesOpcao.add("Data: " + consulta.getData() + ", Horário: " + consulta.getHorario() + ", Paciente: " + consulta.getPaciente().getNome() + ", CPF: " + consulta.getPaciente().getCpf());
                                    System.out.println("Data: " + consulta.getData() + ", Horário: " + consulta.getHorario() + ", Paciente: " + consulta.getPaciente().getNome() + ", CPF: " + consulta.getPaciente().getCpf());
                                }
                            } else {
                                informacoesOpcao.add("Não há consultas agendadas para o médico " + medicoDeConsultaPeriodo.getNome() + " no período de " + dataInicialStr + " a " + dataFinalStr + ".");
                                System.out.println("Não há consultas agendadas para o médico " + medicoDeConsultaPeriodo.getNome() + " no período de " + dataInicialStr + " a " + dataFinalStr + ".");
                            }
                        } else {
                            System.out.println("Médico não encontrado.");
                        }
                    } catch (ParseException e) {
                        System.out.println("Erro ao processar as datas.");
                        e.printStackTrace();
                    }
                    System.out.println("====================================================================");
                    break;
                case 3:
                    //3. Medicos do Paciente
                    System.out.println("Digite o CPF do paciente para buscar os médicos que o atenderam:");
                    String cpfPaciente = scanner.nextLine();
                    Paciente paciente = encontrarPacientePorCpf(pacientes, cpfPaciente);
                    if (paciente != null) {
                        List<Medico> medicosDoPaciente = medicosDoPaciente(paciente, consultas);
                        if (medicosDoPaciente.isEmpty()) {
                            System.out.println("Este paciente não consultou nenhum médico.");
                            informacoesOpcao.add("Este paciente não consultou nenhum médico.");
                        } else {
                            System.out.println("Médicos que Atenderam o paciente " + paciente.getNome() + ":");
                            informacoesOpcao.add("Médicos que Atenderam o paciente " + paciente.getNome() + ":");
                            for (Medico medicosPaciente : medicosDoPaciente) {
                                System.out.println(medicosPaciente.getNome());
                                informacoesOpcao.add(medicosPaciente.getNome());
                            }
                        }
                    } else {
                        System.out.println("Paciente não encontrado.");
                    }


                    System.out.println("====================================================================");
                    break;
                case 4:
                    //4.Quais são todas as consultas que um determinado paciente realizou com
                    //determinado médico?
                    System.out.println("Digite o CPF do paciente:");
                    String cpfPacienteConsultaAnterior = scanner.nextLine();
                    System.out.println("Digite o código único do médico:");
                    String codigoUnicoMedicoConsultaAnterior = scanner.nextLine();

                    Paciente pacienteConsultaAnterior = encontrarPacientePorCpf(pacientes, cpfPacienteConsultaAnterior);
                    Medico medicoConsultaAnterior = encontrarMedicoPorCodigoUnico(medicos, codigoUnicoMedicoConsultaAnterior);


                    if (pacienteConsultaAnterior != null && medicoConsultaAnterior != null) {
                        // Buscar consultas realizadas pelo paciente com o médico no tempo passado
                        List<Consulta> consultasPassadas = consultasPacienteComMedicoPassado(pacienteConsultaAnterior, medicoConsultaAnterior, consultas, sdf, new Date());


                        if (!consultasPassadas.isEmpty()) {
                            informacoesOpcao.add("O Paciente " + pacienteConsultaAnterior.getNome() + " já se consultou com o Médico " + medicoConsultaAnterior.getNome() + " em:");
                            System.out.println("O Paciente " + pacienteConsultaAnterior.getNome() + " já se consultou com o Médico " + medicoConsultaAnterior.getNome() + " em:");
                            for (Consulta consulta : consultasPassadas) {
                                informacoesOpcao.add("Data: " + consulta.getData() + ", Horário: " + consulta.getHorario());
                                System.out.println("Data: " + consulta.getData() + ", Horário: " + consulta.getHorario());
                            }
                        } else {
                            informacoesOpcao.add("Não há consultas do Paciente " + pacienteConsultaAnterior.getNome() + " com o Médico " + medicoConsultaAnterior.getNome() + " no tempo passado.");
                            System.out.println("Não há consultas do Paciente " + pacienteConsultaAnterior.getNome() + " com o Médico " + medicoConsultaAnterior.getNome() + " no tempo passado.");
                        }
                    } else {
                        System.out.println("Paciente ou médico não encontrado.");
                    }
                    break;

                case 5:
                    //.5 Quais são todas as consultas agendadas que um determinado paciente possui?
                    System.out.println("====================================================================");

                    System.out.println("Digite o CPF do paciente para buscar consultas agendadas:");
                    String cpfPacienteAgendado = scanner.nextLine();

                    Paciente pacienteAgendado = encontrarPacientePorCpf(pacientes, cpfPacienteAgendado);
                    if (pacienteAgendado != null) {

                        Date dataAtual = new Date();


                        List<Consulta> consultasDoPaciente = consultasDoPacienteAgendadas(pacienteAgendado, consultas, dataAtual);

                        if (!consultasDoPaciente.isEmpty()) {
                            informacoesOpcao.add("Consultas agendadas para o paciente " + pacienteAgendado.getNome() + ":");
                            System.out.println("Consultas agendadas para o paciente " + pacienteAgendado.getNome() + ":");
                            for (Consulta consulta : consultasDoPaciente) {
                                System.out.println("Data: " + consulta.getData() + ", Horário: " + consulta.getHorario() +
                                        ", Médico: " + consulta.getMedico().getNome());
                                informacoesOpcao.add("Data: " + consulta.getData() + ", Horário: " + consulta.getHorario() +
                                        ", Médico: " + consulta.getMedico().getNome());
                            }
                        } else {
                            System.out.println("O paciente " + pacienteAgendado.getNome() + " não possui consultas agendadas.");
                            informacoesOpcao.add("O paciente " + pacienteAgendado.getNome() + " não possui consultas agendadas.");
                        }
                    } else {
                        System.out.println("Paciente não encontrado.");
                    }

                    System.out.println("====================================================================");
                    break;
                case 6:
                    //6.Pacientes sem consulta por tantos meses
                    // Encontrar pacientes que não consultaram um médico pelo tempo especificado
                    System.out.println("Digite o código único do médico:");
                    String codigoUnicoMedicoSemConsultas = scanner.nextLine();
                    System.out.println("Defina o número de meses para o qual deseja verificar:");
                    int meses = Integer.parseInt(scanner.nextLine());

                    Medico encontrarMedicoSemConsultas = encontrarMedicoPorCodigoUnico(medicos, codigoUnicoMedicoSemConsultas);
                    if (encontrarMedicoSemConsultas != null) {
                        List<Paciente> pacientesSemConsulta = pacientesSemConsultaPorTempo(encontrarMedicoSemConsultas, consultas, meses);

                        if (!pacientesSemConsulta.isEmpty()) {
                            System.out.println("Pacientes do médico " + encontrarMedicoSemConsultas.getNome() + " que não o consultaram há mais de " + meses + " meses:");
                            informacoesOpcao.add("Pacientes do médico " + encontrarMedicoSemConsultas.getNome() + " que não o consultaram há mais de " + meses + " meses:");
                            for (Paciente pacienteSemConsulta : pacientesSemConsulta) {
                                System.out.println(pacienteSemConsulta.getNome());
                                informacoesOpcao.add(pacienteSemConsulta.getNome());
                            }
                        } else {
                            System.out.println("Todos os pacientes do médico " + encontrarMedicoSemConsultas.getNome() + " consultaram nos últimos " + meses + " meses.");
                            informacoesOpcao.add("Todos os pacientes do médico " + encontrarMedicoSemConsultas.getNome() + " consultaram nos últimos " + meses + " meses.");
                        }
                    } else {
                        System.out.println("Médico não encontrado.");
                    }
                    break;

            }
            //Escolha do usuário para encerrar e salvar o arquivo
            Scanner escolhaLoop = new Scanner(System.in);
            Scanner escolhaDeSalvar = new Scanner(System.in);
            System.out.println("Deseja encerrar o programa?\n1. Não\n0. Sim");
            int entrada = escolhaLoop.nextInt();
            System.out.println("Quer salvar os dados em um arquivo?\n1. Não\n0. Sim");
            int entradaSalva = escolhaDeSalvar.nextInt();
            if(entrada == 0 && entradaSalva == 0) {
                System.out.println("Salvando dados e encerrando o programa...");
                System.out.println("Obrigado!");
                salvarDadosEmArquivo(entradaDoUsuario, informacoesOpcao, "dados_salvos.txt"); // Passa a opção escolhida pelo usuário e as informações geradas para o método de salvar
                break;
            }
            else if(entrada == 0 && entradaSalva == 1)
            {
                System.out.println("Obrigado!");
                break;

            }
        }



    }

    //Método para encontrar o médico por código único
    private static Medico encontrarMedicoPorCodigoUnico(List<Medico> medicos, String codigoUnico) {
        for (Medico medico : medicos) {
            if (medico.getCodigoUnico().equals(codigoUnico)) {
                return medico;
            }
        }
        return null;
    }

    //Método para gerar a lista de pacientes de um médico
    private static List<Paciente> pacientesDoMedico(Medico medico, List<Consulta> consultas) {
        List<Paciente> pacientesDoMedico = new ArrayList<>();
        for (Consulta consulta : consultas) {
            if (consulta.getMedico().equals(medico)) {
                pacientesDoMedico.add(consulta.getPaciente());
            }
        }
        return pacientesDoMedico;
    }

    //Método para gerar a lista de consultas de um médico
    private static List<Consulta> consultasDoMedicoNoPeriodo(Medico medico, List<Consulta> consultas, SimpleDateFormat sdf, Date dataInicial, Date dataFinal) {
        List<Consulta> consultasNoPeriodo = new ArrayList<>();
        for (Consulta consulta : consultas) {
            try {
                Date dataConsulta = sdf.parse(consulta.getData());
                if (consulta.getMedico().equals(medico) && dataConsulta.compareTo(dataInicial) >= 0 && dataConsulta.compareTo(dataFinal) <= 0) {
                    consultasNoPeriodo.add(consulta);
                }
            } catch (ParseException e) {
                System.out.println("Erro ao processar a data da consulta.");
                e.printStackTrace();
            }
        }
        consultasNoPeriodo.sort(
                Comparator.comparing((Consulta c) -> {
                    try {
                        return sdf.parse(c.getData());
                    } catch (ParseException e) {
                        throw new IllegalArgumentException("Erro ao processar a data da consulta", e);
                    }
                })
        );


        return consultasNoPeriodo;
    }

    // Método para encontrar um paciente pelo CPF
    private static Paciente encontrarPacientePorCpf(List<Paciente> pacientes, String cpf) {
        for (Paciente paciente : pacientes) {
            if (paciente.getCpf().equals(cpf)) {
                return paciente;
            }
        }
        return null;
    }

    // Método para encontrar todas as consultas de um paciente com um médico em um tempo passado
    private static List<Consulta> consultasPacienteComMedicoPassado(Paciente paciente, Medico medico, List<Consulta> consultas, SimpleDateFormat sdf, Date dataAtual) {
        List<Consulta> consultasPassadas = new ArrayList<>();
        for (Consulta consulta : consultas) {
            try {
                Date dataConsulta = sdf.parse(consulta.getData());
                if (consulta.getPaciente().equals(paciente) && consulta.getMedico().equals(medico) && dataConsulta.before(dataAtual)) {
                    consultasPassadas.add(consulta);
                }
            } catch (ParseException e) {
                System.out.println("Erro ao processar a data da consulta.");
                e.printStackTrace();
            }
        }
        return consultasPassadas;
    }

    //Método para achar todos os médicos de um paciente
    private static List<Medico> medicosDoPaciente(Paciente paciente, List<Consulta> consultas) {
        Set<Medico> medicosSet = new HashSet<>();
        for (Consulta consulta : consultas) {
            if (consulta.getPaciente().equals(paciente)) {
                medicosSet.add(consulta.getMedico());
            }
        }
        return new ArrayList<>(medicosSet);
    }

    //Método para achar as consultas agendadas de um paciente
    private static List<Consulta> consultasDoPacienteAgendadas(Paciente paciente, List<Consulta> consultas, Date dataAtual) {
        List<Consulta> consultasAgendadas = new ArrayList<>();
        for (Consulta consulta : consultas) {
            try {
                // Converta a data da consulta para um objeto Date
                Date dataConsulta = sdf.parse(consulta.getData());

                // Verifique se a consulta está agendada para um tempo posterior ao momento atual
                if (dataConsulta.after(dataAtual) && consulta.getPaciente().equals(paciente)) {
                    consultasAgendadas.add(consulta);
                }
            } catch (ParseException e) {
                System.out.println("Erro ao processar a data da consulta.");
                e.printStackTrace();
            }
        }
        return consultasAgendadas;
    }

    //Método para mostrar pacientes que não se consultaram por um tempo
    private static List<Paciente> pacientesSemConsultaPorTempo(Medico medico, List<Consulta> consultas, int meses) {
        List<Paciente> pacientesSemConsulta = new ArrayList<>();
        Date dataAtual = new Date();

        // Calcula a data limite com base nos meses especificados
        long milissegundosPorDia = 1000 * 60 * 60 * 24;
        long milissegundosPorMes = milissegundosPorDia * 30;
        long tempoLimite = milissegundosPorMes * meses;
        long dataLimite = dataAtual.getTime() - tempoLimite;
        Date dataLimiteObj = new Date(dataLimite);

        for (Consulta consulta : consultas) {
            try {
                // Converta a data da consulta para um objeto Date
                Date dataConsulta = sdf.parse(consulta.getData());

                // Verifique se a consulta foi realizada pelo médico desejado
                if (consulta.getMedico().equals(medico)) {
                    // Verifique se a data da consulta está antes do tempo limite
                    if (dataConsulta.before(dataLimiteObj)) {
                        // Adicione o paciente associado à consulta à lista de pacientes sem consulta
                        pacientesSemConsulta.add(consulta.getPaciente());
                    }
                }
            } catch (ParseException e) {
                System.out.println("Erro ao processar a data da consulta.");
                e.printStackTrace();
            }
        }
        return pacientesSemConsulta;
    }

    //Método para salvar os dados no arquivo.txt
    private static void salvarDadosEmArquivo(int opcao, List<String> informacoes, String nomeArquivo) {
        try {
            FileWriter writer = new FileWriter(nomeArquivo);
            writer.write("Opção escolhida pelo usuário: " + opcao + "\n"); // Salva a opção escolhida pelo usuário
            for (String info : informacoes) {
                writer.write(info + "\n");
            }
            writer.close();
            System.out.println("Dados salvos em '" + nomeArquivo + "'.");
        } catch (IOException e) {
            System.out.println("Erro ao salvar os dados em arquivo.");
            e.printStackTrace();
        }
    }


}
