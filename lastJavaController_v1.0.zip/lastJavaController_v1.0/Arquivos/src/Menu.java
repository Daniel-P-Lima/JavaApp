import javax.swing.*;
import java.awt.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;

public class Menu extends JFrame {
    private JTextField codigoMedicoField;
    private JTextArea outputArea;
    private List<Medico> medicos;
    private List<Consulta> consultas;
    private JTextField dataInicialField;
    private JTextField dataFinalField;
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");


    public Menu(List<Medico> medicos, List<Consulta> consultas) {
        this.medicos = medicos;
        this.consultas = consultas;


        setTitle("Consultório Médico");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // campos de entrada e saída do formulario
        codigoMedicoField = new JTextField(20);
        outputArea = new JTextArea(20, 60);
        outputArea.setEditable(false);
        dataInicialField = new JTextField(10); // Inicializando dataInicial
        dataFinalField = new JTextField(10);

        // botões
        JButton btnExibirPacientes = new JButton("Exibir Pacientes do Médico");
        btnExibirPacientes.addActionListener(e -> exibirPacientesDoMedico());

        JButton btnExibirConsultasDatas = new JButton("Exibir Consultas nas Datas");
        btnExibirConsultasDatas.addActionListener(e -> consultasDoMedicoNoPeriodo());

        setLayout(new FlowLayout());

        // Adiciona os componentes ao frame
        add(new JLabel("Código do Médico:"));
        add(codigoMedicoField);
        add(btnExibirPacientes);
        add(btnExibirConsultasDatas);
        add(new JLabel("Data Inicial (dd/MM/yyyy):"));
        add(dataInicialField);
        add(new JLabel("Data Final (dd/MM/yyyy):"));
        add(dataFinalField);

        add(new JScrollPane(outputArea));
    }

    private void exibirPacientesDoMedico() {
        String codigoMedico = codigoMedicoField.getText();
        String resultado = Controller.exibirPacientesDoMedico(codigoMedico, medicos, consultas);
        outputArea.setText(resultado);
    }

    //2. Buscar consultas agendadas para um médico dentro de um período

    private void consultasDoMedicoNoPeriodo() {
        String codigoMedico = codigoMedicoField.getText();
        String dataInicialText = dataInicialField.getText();
        String dataFinalText = dataFinalField.getText();

        try {

            Date dataInicio = sdf.parse(dataInicialText);
            Date dataFim = sdf.parse(dataFinalText);


            Medico medico = Controller.encontrarMedicoPorCodigoUnico(medicos, codigoMedico);

            if (medico != null) {

                List<Consulta> consultasNoPeriodo = Controller.consultasDoMedicoNoPeriodo(medico, consultas, dataInicio, dataFim);


                StringBuilder resultado = new StringBuilder();
                for (Consulta consulta : consultasNoPeriodo) {
                    resultado.append(consulta.toString()).append("\n");
                }


                if (resultado.length() == 0) {
                    resultado.append("Nenhuma consulta encontrada para o período especificado.");
                }


                outputArea.setText(resultado.toString());
            } else {
                JOptionPane.showMessageDialog(this, "Médico não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Formato de data inválido. Por favor, use dd/MM/yyyy.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao buscar consultas. Verifique os dados inseridos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }






    public static void main(String[] args) {
        List<List<String>> dadosMedicos = LeituraMedicos.lerDados("Arquivos/medicos.csv");
        List<List<String>> dadosPacientes = LeituraPacientes.lerDados("Arquivos/pacientes.csv");
        List<List<String>> dadosConsultas = LeituraConsultas.lerDados("Arquivos/consultas.csv");

        List<Medico> medicos = Medico.criarMedicos(dadosMedicos);

        List<Paciente> pacientes = Paciente.criarPacientes(dadosPacientes);

        List<Consulta> consultas = Consulta.criarConsultas(dadosConsultas, medicos, pacientes);

        SwingUtilities.invokeLater(() -> {
            Menu menu = new Menu(medicos, consultas);
            menu.setVisible(true);
        });
    }
}
