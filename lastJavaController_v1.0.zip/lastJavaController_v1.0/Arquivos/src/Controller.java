import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class Controller {
    public static String exibirPacientesDoMedico(String codigoMedico, List<Medico> medicos, List<Consulta> consultas) {
        StringBuilder resultado = new StringBuilder();
        Medico medico = encontrarMedicoPorCodigoUnico(medicos, codigoMedico);
        if (medico != null) {
            resultado.append("Pacientes do Médico ").append(medico.getNome()).append(":\n");
            List<Paciente> pacientesDoMedico = pacientesDoMedico(medico, consultas);
            if (pacientesDoMedico.isEmpty()) {
                resultado.append("Este médico não possui consultas.\n");
            } else {
                for (Paciente paciente : pacientesDoMedico) {
                    resultado.append(paciente.getNome()).append("\n");
                }
            }
        } else {
            resultado.append("Médico não encontrado.\n");
        }
        resultado.append("====================================================================\n");
        return resultado.toString();
    }

    public static Medico encontrarMedicoPorCodigoUnico(List<Medico> medicos, String codigoUnico) {
        for (Medico medico : medicos) {
            if (medico.getCodigoUnico().equals(codigoUnico)) {
                return medico;
            }
        }
        return null;
    }

    private static List<Paciente> pacientesDoMedico(Medico medico, List<Consulta> consultas) {
        List<Paciente> pacientesDoMedico = new ArrayList<>();
        for (Consulta consulta : consultas) {
            if (consulta.getMedico().equals(medico)) {
                pacientesDoMedico.add(consulta.getPaciente());
            }
        }
        return pacientesDoMedico;
    }

    //Método para gerar a lista de consultas de um médico
    public static List<Consulta> consultasDoMedicoNoPeriodo(Medico medico, List<Consulta> consultas, Date dataInicial, Date dataFinal) {
        List<Consulta> consultasNoPeriodo = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        for (Consulta consulta : consultas) {
            try {
                Date dataConsulta = sdf.parse(consulta.getData());
                if (consulta.getMedico().equals(medico) && dataConsulta.compareTo(dataInicial) >= 0 && dataConsulta.compareTo(dataFinal) <= 0) {
                    consultasNoPeriodo.add(consulta);
                }
            } catch (ParseException e) {
                System.out.println("Erro ao processar a data da consulta.");
                e.printStackTrace();
            }
        }

        consultasNoPeriodo.sort(Comparator.comparing(Consulta::getHorario));
        return consultasNoPeriodo;
    }
}
