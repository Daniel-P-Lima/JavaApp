import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;

public class Consulta {
    private String data;
    private String horario;
    private Medico medico;
    private Paciente paciente;

    public Consulta(String data, String horario, Medico medico, Paciente paciente) {
        this.data = data;
        this.horario = horario;
        this.medico = medico;
        this.paciente = paciente;
    }

    public String getData() {
        return data;
    }

    public String getHorario() {
        return horario;
    }

    public Medico getMedico() {
        return medico;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public static List<Consulta> criarConsultas(List<List<String>> dadosConsultas, List<Medico> medicos, List<Paciente> pacientes) {
        List<Consulta> consultas = new ArrayList<>();
        for (List<String> linha : dadosConsultas) {
            String data = linha.get(0);
            String horario = linha.get(1);
            String codigoUnicoMedico = linha.get(2);
            String cpfPaciente = linha.get(3);
            Medico medico = encontrarMedicoPorCodigoUnico(medicos, codigoUnicoMedico);
            Paciente paciente = encontrarPacientePorCpf(pacientes, cpfPaciente);
            if (medico != null && paciente != null) {
                consultas.add(new Consulta(data, horario, medico, paciente));
            }


        }
        return consultas;
    }

    private static Medico encontrarMedicoPorCodigoUnico(List<Medico> medicos, String codigoUnico) {
        for (Medico medico : medicos) {
            if (medico.getCodigoUnico().equals(codigoUnico)) {
                return medico;
            }
        }
        return null;
    }

    private static Paciente encontrarPacientePorCpf(List<Paciente> pacientes, String cpf) {
        for (Paciente paciente : pacientes) {
            if (paciente.getCpf().equals(cpf)) {
                return paciente;
            }
        }
        return null;
    }

    public static List<Consulta> consultasDoMedicoNoPeriodo(Medico medico, List<Consulta> consultas, String dataInicial, String dataFinal) {
        List<Consulta> consultasNoPeriodo = new ArrayList<>();
        for (Consulta consulta : consultas) {
            if (consulta.getMedico().equals(medico) && consulta.estaNoPeriodo(dataInicial, dataFinal)) {
                consultasNoPeriodo.add(consulta);
            }
        }
        consultasNoPeriodo.sort(Comparator.comparing(Consulta::getHorario));
        return consultasNoPeriodo;
    }

    private boolean estaNoPeriodo(String dataInicial, String dataFinal) {
        return data.compareTo(dataInicial) >= 0 && data.compareTo(dataFinal) <= 0;
    }

    @Override
    public String toString() {
        return "Data: " + getData() + ", Horário: " + getHorario() + ", Médico: " + getMedico().getNome() + ", Paciente: " + getPaciente().getNome(); // Adapte para os atributos que você deseja exibir
    }
}
