public class MedicoNaoEncontradoException extends Exception {
    public MedicoNaoEncontradoException(String message) {
        super(message);
    }
}

