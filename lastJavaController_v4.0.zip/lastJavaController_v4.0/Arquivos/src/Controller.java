import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class Controller {
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    public static String exibirPacientesDoMedico(String codigoMedico, List<Medico> medicos, List<Consulta> consultas) throws MedicoNaoEncontradoException {
        StringBuilder resultado = new StringBuilder();
        Medico medico = encontrarMedicoPorCodigoUnico(medicos, codigoMedico);
        if (medico != null) {
            resultado.append("Pacientes do Médico ").append(medico.getNome()).append(":\n");
            List<Paciente> pacientesDoMedico = pacientesDoMedico(medico, consultas);
            if (pacientesDoMedico.isEmpty()) {
                resultado.append("Este médico não possui consultas.\n");
            } else {
                for (Paciente paciente : pacientesDoMedico) {
                    resultado.append(paciente.getNome()).append("\n");
                }
            }
        } else {
            throw new MedicoNaoEncontradoException("Médico não encontrado com o código: " + codigoMedico);
        }
        resultado.append("====================================================================\n");
        return resultado.toString();
    }

    public static Medico encontrarMedicoPorCodigoUnico(List<Medico> medicos, String codigoUnico) throws MedicoNaoEncontradoException {
        for (Medico medico : medicos) {
            if (medico.getCodigoUnico().equals(codigoUnico)) {
                return medico;
            }
        }
        throw new MedicoNaoEncontradoException("Médico não encontrado com o código: " + codigoUnico);
    }

    private static List<Paciente> pacientesDoMedico(Medico medico, List<Consulta> consultas) {
        List<Paciente> pacientesDoMedico = new ArrayList<>();
        for (Consulta consulta : consultas) {
            if (consulta.getMedico().equals(medico)) {
                pacientesDoMedico.add(consulta.getPaciente());
            }
        }
        return pacientesDoMedico;
    }

    public static List<Consulta> consultasDoMedicoNoPeriodo(Medico medico, List<Consulta> consultas, Date dataInicial, Date dataFinal) {
        List<Consulta> consultasNoPeriodo = new ArrayList<>();
        for (Consulta consulta : consultas) {
            try {
                Date dataConsulta = sdf.parse(consulta.getData());
                if (consulta.getMedico().equals(medico) && dataConsulta.compareTo(dataInicial) >= 0 && dataConsulta.compareTo(dataFinal) <= 0) {
                    consultasNoPeriodo.add(consulta);
                }
            } catch (ParseException e) {
                System.out.println("Erro ao processar a data da consulta.");
                e.printStackTrace();
            }
        }
        consultasNoPeriodo.sort(Comparator.comparing(Consulta::getHorario));
        return consultasNoPeriodo;
    }

    public static String exibirMedicosDoPaciente(String cpfPaciente, List<Paciente> pacientes, List<Consulta> consultas) throws PacienteNaoEncontradoException {
        StringBuilder resultado = new StringBuilder();
        Paciente paciente = encontrarPacientePorCpf(pacientes, cpfPaciente);
        if (paciente != null) {
            List<Medico> medicosDoPaciente = medicosDoPaciente(paciente, consultas);
            if (medicosDoPaciente.isEmpty()) {
                resultado.append("Este paciente não consultou nenhum médico.\n");
            } else {
                resultado.append("Médicos que Atenderam o paciente ").append(paciente.getNome()).append(":\n");
                for (Medico medico : medicosDoPaciente) {
                    resultado.append(medico.getNome()).append("\n");
                }
            }
        } else {
            throw new PacienteNaoEncontradoException("Paciente não encontrado com o CPF: " + cpfPaciente);
        }
        resultado.append("====================================================================\n");
        return resultado.toString();
    }

    public static Paciente encontrarPacientePorCpf(List<Paciente> pacientes, String cpf) throws PacienteNaoEncontradoException {
        for (Paciente paciente : pacientes) {
            if (paciente.getCpf().equals(cpf)) {
                return paciente;
            }
        }
        throw new PacienteNaoEncontradoException("Paciente não encontrado com o CPF: " + cpf);
    }

    private static List<Medico> medicosDoPaciente(Paciente paciente, List<Consulta> consultas) {
        List<Medico> medicosDoPaciente = new ArrayList<>();
        for (Consulta consulta : consultas) {
            if (consulta.getPaciente().equals(paciente)) {
                if (!medicosDoPaciente.contains(consulta.getMedico())) {
                    medicosDoPaciente.add(consulta.getMedico());
                }
            }
        }
        return medicosDoPaciente;
    }

    public static List<Consulta> consultasDoPacienteAgendadas(Paciente paciente, List<Consulta> consultas, Date dataAtual) {
        List<Consulta> consultasAgendadas = new ArrayList<>();
        for (Consulta consulta : consultas) {
            try {
                Date dataConsulta = sdf.parse(consulta.getData());
                if (dataConsulta.after(dataAtual) && consulta.getPaciente().equals(paciente)) {
                    consultasAgendadas.add(consulta);
                }
            } catch (ParseException e) {
                System.out.println("Erro ao processar a data da consulta.");
                e.printStackTrace();
            }
        }
        return consultasAgendadas;
    }

    public static List<Paciente> pacientesSemConsultaPorTempo(Medico medico, List<Consulta> consultas, int meses) {
        List<Paciente> pacientesSemConsulta = new ArrayList<>();
        Date dataAtual = new Date();
        long milissegundosPorDia = 1000 * 60 * 60 * 24;
        long milissegundosPorMes = milissegundosPorDia * 30;
        long tempoLimite = milissegundosPorMes * meses;
        long dataLimite = dataAtual.getTime() - tempoLimite;
        Date dataLimiteObj = new Date(dataLimite);

        for (Consulta consulta : consultas) {
            try {
                Date dataConsulta = sdf.parse(consulta.getData());
                if (consulta.getMedico().equals(medico)) {
                    if (dataConsulta.before(dataLimiteObj)) {
                        pacientesSemConsulta.add(consulta.getPaciente());
                    }
                }
            } catch (ParseException e) {
                System.out.println("Erro ao processar a data da consulta.");
                e.printStackTrace();
            }
        }
        return pacientesSemConsulta;
    }

    public static String exibirConsultasPacienteComMedico(String cpfPaciente, String codigoMedico, List<Paciente> pacientes, List<Medico> medicos, List<Consulta> consultas) throws PacienteNaoEncontradoException, MedicoNaoEncontradoException {
        StringBuilder resultado = new StringBuilder();
        Paciente pacienteConsultaAnterior = encontrarPacientePorCpf(pacientes, cpfPaciente);
        Medico medicoConsultaAnterior = encontrarMedicoPorCodigoUnico(medicos, codigoMedico);

        if (pacienteConsultaAnterior != null && medicoConsultaAnterior != null) {
            List<Consulta> consultasPassadas = consultasPacienteComMedicoPassado(pacienteConsultaAnterior, medicoConsultaAnterior, consultas);

            if (!consultasPassadas.isEmpty()) {
                resultado.append("O Paciente ").append(pacienteConsultaAnterior.getNome()).append(" já se consultou com o Médico ").append(medicoConsultaAnterior.getNome()).append(" em:\n");
                for (Consulta consulta : consultasPassadas) {
                    resultado.append("Data: ").append(consulta.getData()).append(", Horário: ").append(consulta.getHorario()).append("\n");
                }
            } else {
                resultado.append("Não há consultas do Paciente ").append(pacienteConsultaAnterior.getNome()).append(" com o Médico ").append(medicoConsultaAnterior.getNome()).append(" no tempo passado.");
            }
        }
        return resultado.toString();
    }

    private static List<Consulta> consultasPacienteComMedicoPassado(Paciente paciente, Medico medico, List<Consulta> consultas) {
        List<Consulta> consultasPassadas = new ArrayList<>();
        for (Consulta consulta : consultas) {
            if (consulta.getPaciente().equals(paciente) && consulta.getMedico().equals(medico)) {
                try {
                    Date dataConsulta = sdf.parse(consulta.getData());
                    if (dataConsulta.before(new Date())) {
                        consultasPassadas.add(consulta);
                    }
                } catch (ParseException e) {
                    System.out.println("Erro ao processar a data da consulta.");
                    e.printStackTrace();
                }
            }
        }
        return consultasPassadas;
    }
}
