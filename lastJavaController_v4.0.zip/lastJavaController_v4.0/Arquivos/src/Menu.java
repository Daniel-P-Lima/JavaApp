import javax.swing.*;
import java.awt.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class Menu extends JFrame {
    private JTextField codigoMedicoField;
    private JTextField cpfPacienteField;
    private JTextField cpfPacienteFieldConsultaAnterior;
    private JTextField codigoMedicoFieldConsultaAnterior;
    private JTextArea outputArea;
    private List<Medico> medicos;
    private List<Paciente> pacientes;
    private List<Consulta> consultas;
    private JTextField dataInicialField;
    private JTextField dataFinalField;
    private JTextField mesesField;
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    public Menu(List<Medico> medicos, List<Paciente> pacientes, List<Consulta> consultas) {
        this.medicos = medicos;
        this.consultas = consultas;
        this.pacientes = pacientes;

        setTitle("Consultório Médico");
        setSize(1280, 728);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Campos de entrada e saída do formulário
        codigoMedicoField = new JTextField(20);
        cpfPacienteField = new JTextField(20);
        cpfPacienteFieldConsultaAnterior = new JTextField(20);
        codigoMedicoFieldConsultaAnterior = new JTextField(20);
        outputArea = new JTextArea(20, 60);
        outputArea.setEditable(false);
        dataInicialField = new JTextField(10);
        dataFinalField = new JTextField(10);
        mesesField = new JTextField(5);

        // Botões
        JButton btnExibirPacientes = new JButton("Exibir Pacientes do Médico");
        btnExibirPacientes.addActionListener(e -> exibirPacientesDoMedico());

        JButton btnExibirMedicosPaciente = new JButton("Exibir Médicos do Paciente");
        btnExibirMedicosPaciente.addActionListener(e -> exibirMedicosDoPaciente());

        JButton btnExibirConsultasDatas = new JButton("Exibir Consultas nas Datas");
        btnExibirConsultasDatas.addActionListener(e -> consultasDoMedicoNoPeriodo());

        JButton btnConsultasDeUmPaciente = new JButton("Exibir todas as consultas de um Paciente");
        btnConsultasDeUmPaciente.addActionListener(e -> exibirConsultasDePaciente());

        JButton btnPacientesSemConsulta = new JButton("Pacientes sem consulta por meses");
        btnPacientesSemConsulta.addActionListener(e -> exibirPacientesSemConsultaPorTempo());

        JButton btnConsultasPacienteComMedico = new JButton("Consultas realizadas");
        btnConsultasPacienteComMedico.addActionListener(e -> exibirConsultasPacienteComMedico());

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Adiciona os componentes ao frame
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(new JLabel("Código do Médico:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        add(codigoMedicoField, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        add(btnExibirPacientes, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("Data Inicial (dd/MM/yyyy):"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        add(dataInicialField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("Data Final (dd/MM/yyyy):"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        add(dataFinalField, gbc);

        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.gridheight = 2;
        add(btnExibirConsultasDatas, gbc);
        gbc.gridheight = 1;

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(new JLabel("CPF do Paciente:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        add(cpfPacienteField, gbc);

        gbc.gridx = 2;
        gbc.gridy = 3;
        add(btnConsultasDeUmPaciente, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(new JLabel("Meses:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        add(mesesField, gbc);

        gbc.gridx = 2;
        gbc.gridy = 4;
        add(btnPacientesSemConsulta, gbc);

        gbc.gridx = 3;
        gbc.gridy = 3;
        add(btnExibirMedicosPaciente, gbc);  // Botão para exibir médicos do paciente

        gbc.gridx = 0;
        gbc.gridy = 5;
        add(new JLabel("CPF do Paciente (Consultas Anteriores):"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        add(cpfPacienteFieldConsultaAnterior, gbc);

        gbc.gridx = 2;
        gbc.gridy = 5;
        add(new JLabel("Código do Médico (Consultas Anteriores):"), gbc);

        gbc.gridx = 3;
        gbc.gridy = 5;
        add(codigoMedicoFieldConsultaAnterior, gbc);

        gbc.gridx = 4;
        gbc.gridy = 5;
        add(btnConsultasPacienteComMedico, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 5;
        gbc.fill = GridBagConstraints.BOTH;
        add(new JScrollPane(outputArea), gbc);
    }

    private void exibirPacientesDoMedico() {
        String codigoMedico = codigoMedicoField.getText();
        try {
            String resultado = Controller.exibirPacientesDoMedico(codigoMedico, medicos, consultas);
            outputArea.setText(resultado);
        } catch (MedicoNaoEncontradoException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exibirMedicosDoPaciente() {
        String cpfPaciente = cpfPacienteField.getText();
        try {
            String resultado = Controller.exibirMedicosDoPaciente(cpfPaciente, pacientes, consultas);
            outputArea.setText(resultado);
        } catch (PacienteNaoEncontradoException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void consultasDoMedicoNoPeriodo() {
        String codigoMedico = codigoMedicoField.getText();
        String dataInicialText = dataInicialField.getText();
        String dataFinalText = dataFinalField.getText();

        try {
            Date dataInicio = sdf.parse(dataInicialText);
            Date dataFim = sdf.parse(dataFinalText);

            Medico medico = Controller.encontrarMedicoPorCodigoUnico(medicos, codigoMedico);

            if (medico != null) {
                List<Consulta> consultasNoPeriodo = Controller.consultasDoMedicoNoPeriodo(medico, consultas, dataInicio, dataFim);

                consultasNoPeriodo.sort(
                        Comparator.comparing((Consulta consulta) -> {
                            try {
                                Date data = sdf.parse(consulta.getData());
                                Calendar calendar = Calendar.getInstance();
                                calendar.setTime(data);
                                return calendar.get(Calendar.MONTH);
                            } catch (ParseException e) {
                                throw new IllegalArgumentException("Erro ao processar a data da consulta", e);
                            }
                        })
                );

                StringBuilder resultado = new StringBuilder();
                for (Consulta consulta : consultasNoPeriodo) {
                    resultado.append(consulta.toString()).append("\n");
                }

                if (resultado.length() == 0) {
                    resultado.append("Nenhuma consulta encontrada para o período especificado.");
                }

                outputArea.setText(resultado.toString());
            } else {
                JOptionPane.showMessageDialog(this, "Médico não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Formato de data inválido. Por favor, use dd/MM/yyyy.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao buscar consultas. Verifique os dados inseridos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exibirConsultasDePaciente() {
        String cpfPaciente = cpfPacienteField.getText();

        try {
            Paciente pacienteAgendado = Controller.encontrarPacientePorCpf(pacientes, cpfPaciente);
            Date dataAtual = new Date();
            List<Consulta> consultasDoPaciente = Controller.consultasDoPacienteAgendadas(pacienteAgendado, consultas, dataAtual);

            StringBuilder resultado = new StringBuilder();
            if (!consultasDoPaciente.isEmpty()) {
                resultado.append("Consultas agendadas para o paciente ").append(pacienteAgendado.getNome()).append(":\n");
                for (Consulta consulta : consultasDoPaciente) {
                    resultado.append("Data: ").append(consulta.getData()).append(", Horário: ").append(consulta.getHorario())
                            .append(", Médico: ").append(consulta.getMedico().getNome()).append("\n");
                }
            } else {
                resultado.append("O paciente ").append(pacienteAgendado.getNome()).append(" não possui consultas agendadas.");
            }

            outputArea.setText(resultado.toString());
        } catch (PacienteNaoEncontradoException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exibirConsultasPacienteComMedico() {
        String cpfPaciente = cpfPacienteFieldConsultaAnterior.getText();
        String codigoMedico = codigoMedicoFieldConsultaAnterior.getText();
        try {
            String resultado = Controller.exibirConsultasPacienteComMedico(cpfPaciente, codigoMedico, pacientes, medicos, consultas);
            outputArea.setText(resultado);
        } catch (PacienteNaoEncontradoException | MedicoNaoEncontradoException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exibirPacientesSemConsultaPorTempo() {
        String codigoMedico = codigoMedicoField.getText();
        String mesesText = mesesField.getText();
        try {
            int meses = Integer.parseInt(mesesText);

            Medico medico = Controller.encontrarMedicoPorCodigoUnico(medicos, codigoMedico);
            if (medico != null) {
                List<Paciente> pacientesSemConsulta = Controller.pacientesSemConsultaPorTempo(medico, consultas, meses);
                StringBuilder resultado = new StringBuilder();
                if (!pacientesSemConsulta.isEmpty()) {
                    resultado.append("Pacientes do médico ").append(medico.getNome()).append(" que não o consultaram há mais de ").append(meses).append(" meses:\n");
                    for (Paciente paciente : pacientesSemConsulta) {
                        resultado.append(paciente.getNome()).append("\n");
                    }
                } else {
                    resultado.append("Todos os pacientes do médico ").append(medico.getNome()).append(" consultaram nos últimos ").append(meses).append(" meses.");
                }
                outputArea.setText(resultado.toString());
            } else {
                JOptionPane.showMessageDialog(this, "Médico não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException | MedicoNaoEncontradoException e) {
            JOptionPane.showMessageDialog(this, "Formato de número inválido. Por favor, insira um número inteiro.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        List<List<String>> dadosMedicos = LeituraMedicos.lerDados("Arquivos/medicos.csv");
        List<List<String>> dadosPacientes = LeituraPacientes.lerDados("Arquivos/pacientes.csv");
        List<List<String>> dadosConsultas = LeituraConsultas.lerDados("Arquivos/consultas.csv");

        List<Medico> medicos = Medico.criarMedicos(dadosMedicos);
        List<Paciente> pacientes = Paciente.criarPacientes(dadosPacientes);
        List<Consulta> consultas = Consulta.criarConsultas(dadosConsultas, medicos, pacientes);

        SwingUtilities.invokeLater(() -> {
            Menu menu = new Menu(medicos, pacientes, consultas);
            menu.setVisible(true);
        });
    }
}
