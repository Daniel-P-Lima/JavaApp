import java.io.*;
import java.util.*;

public class LeituraPacientes {
    public static List<List<String>> lerDados(String nomeArquivo) {
        String SEPARADOR = ",";
        List<List<String>> tabela = new ArrayList<>();

        try {
            File arquivo = new File(nomeArquivo);
            Scanner scanner_arquivo = new Scanner(arquivo);
            String cabecalho = scanner_arquivo.nextLine(); // Ignora o cabeçalho
            while(scanner_arquivo.hasNextLine())
            {
                String linha = scanner_arquivo.nextLine();
                List<String> registro = Arrays.asList(linha.split(SEPARADOR));
                tabela.add(registro);
            }
        }
        catch (Exception e )
        {
            e.printStackTrace();
        }

        return tabela;
    }
}
