import java.io.*;
import java.util.*;

public class LeituraMedicos {
    public static List<List<String>> lerDados(String nomeArquivo) {
        String SEPARADOR = ",";
        List<List<String>> tabela = new ArrayList<>();

        try {
            File arquivo = new File(nomeArquivo);
            Scanner scanner_arquivo = new Scanner(arquivo);
            String cabecalho = scanner_arquivo.nextLine();
            while(scanner_arquivo.hasNextLine())
            {
                String linha = scanner_arquivo.nextLine();
                Scanner scanner_linha = new Scanner(linha);
                scanner_linha.useDelimiter(SEPARADOR);
                List<String> registro = new ArrayList<>();
                while(scanner_linha.hasNext())
                {
                    String campo = scanner_linha.next();
                    registro.add(campo);
                }
                tabela.add(registro);
            }
        }
        catch (Exception e )
        {
            e.printStackTrace();
        }

        return tabela;
    }
}
