import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;

public class Controller {
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    public static String exibirPacientesDoMedico(String codigoMedico, List<Medico> medicos, List<Consulta> consultas) {
        StringBuilder resultado = new StringBuilder();
        Medico medico = encontrarMedicoPorCodigoUnico(medicos, codigoMedico);
        if (medico != null) {
            resultado.append("Pacientes do Médico ").append(medico.getNome()).append(":\n");
            List<Paciente> pacientesDoMedico = pacientesDoMedico(medico, consultas);
            if (pacientesDoMedico.isEmpty()) {
                resultado.append("Este médico não possui consultas.\n");
            } else {
                for (Paciente paciente : pacientesDoMedico) {
                    resultado.append(paciente.getNome()).append("\n");
                }
            }
        } else {
            resultado.append("Médico não encontrado.\n");
        }
        resultado.append("====================================================================\n");
        return resultado.toString();
    }

    public static Medico encontrarMedicoPorCodigoUnico(List<Medico> medicos, String codigoUnico) {
        for (Medico medico : medicos) {
            if (medico.getCodigoUnico().equals(codigoUnico)) {
                return medico;
            }
        }
        return null;
    }

    private static List<Paciente> pacientesDoMedico(Medico medico, List<Consulta> consultas) {
        List<Paciente> pacientesDoMedico = new ArrayList<>();
        for (Consulta consulta : consultas) {
            if (consulta.getMedico().equals(medico)) {
                pacientesDoMedico.add(consulta.getPaciente());
            }
        }
        return pacientesDoMedico;
    }

    //Método para gerar a lista de consultas de um médico
    public static List<Consulta> consultasDoMedicoNoPeriodo(Medico medico, List<Consulta> consultas, Date dataInicial, Date dataFinal) {
        List<Consulta> consultasNoPeriodo = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        for (Consulta consulta : consultas) {
            try {
                Date dataConsulta = sdf.parse(consulta.getData());
                if (consulta.getMedico().equals(medico) && dataConsulta.compareTo(dataInicial) >= 0 && dataConsulta.compareTo(dataFinal) <= 0) {
                    consultasNoPeriodo.add(consulta);
                }
            } catch (ParseException e) {
                System.out.println("Erro ao processar a data da consulta.");
                e.printStackTrace();
            }
        }

        consultasNoPeriodo.sort(Comparator.comparing(Consulta::getHorario));
        return consultasNoPeriodo;
    }



    //.5 Quais são todas as consultas agendadas que um determinado paciente possui?
    public static Paciente encontrarPacientePorCpf(List<Paciente> pacientes, String cpf) {
        for (Paciente paciente : pacientes) {
            if (paciente.getCpf().equals(cpf)) {
                return paciente;
            }
        }
        return null;
    }

    public static List<Consulta> consultasDoPacienteAgendadas(Paciente paciente, List<Consulta> consultas, Date dataAtual) {
        List<Consulta> consultasAgendadas = new ArrayList<>();
        for (Consulta consulta : consultas) {
            try {
                // Converta a data da consulta para um objeto Date
                Date dataConsulta = sdf.parse(consulta.getData());

                // Verifique se a consulta está agendada para um tempo posterior ao momento atual
                if (dataConsulta.after(dataAtual) && consulta.getPaciente().equals(paciente)) {
                    consultasAgendadas.add(consulta);
                }
            } catch (ParseException e) {
                System.out.println("Erro ao processar a data da consulta.");
                e.printStackTrace();
            }
        }
        return consultasAgendadas;
    }

    //6.Pacientes sem consulta por tantos meses
    // Encontrar pacientes que não consultaram um médico pelo tempo especificado
    public static List<Paciente> pacientesSemConsultaPorTempo(Medico medico, List<Consulta> consultas, int meses) {
        List<Paciente> pacientesSemConsulta = new ArrayList<>();
        Date dataAtual = new Date();

        // Calcula a data limite com base nos meses especificados
        long milissegundosPorDia = 1000 * 60 * 60 * 24;
        long milissegundosPorMes = milissegundosPorDia * 30;
        long tempoLimite = milissegundosPorMes * meses;
        long dataLimite = dataAtual.getTime() - tempoLimite;
        Date dataLimiteObj = new Date(dataLimite);

        for (Consulta consulta : consultas) {
            try {
                // Converta a data da consulta para um objeto Date
                Date dataConsulta = sdf.parse(consulta.getData());

                // Verifique se a consulta foi realizada pelo médico desejado
                if (consulta.getMedico().equals(medico)) {
                    // Verifique se a data da consulta está antes do tempo limite
                    if (dataConsulta.before(dataLimiteObj)) {
                        // Adicione o paciente associado à consulta à lista de pacientes sem consulta
                        pacientesSemConsulta.add(consulta.getPaciente());
                    }
                }
            } catch (ParseException e) {
                System.out.println("Erro ao processar a data da consulta.");
                e.printStackTrace();
            }
        }
        return pacientesSemConsulta;
    }
}
