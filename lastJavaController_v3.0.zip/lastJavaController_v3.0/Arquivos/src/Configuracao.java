import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Configuracao implements Serializable {
    private int maximoGeracoes;
    private List<Medico> medicos;

    public Configuracao() {
        this.maximoGeracoes = 3; // Exemplo de valor padrão
        this.medicos = new ArrayList<>();
    }

    public int getMaximoGeracoes() {
        return maximoGeracoes;
    }

    public void setMaximoGeracoes(int maximoGeracoes) {
        this.maximoGeracoes = maximoGeracoes;
    }

    public List<Medico> getMedicos() {
        return medicos;
    }

    public void setMedicos(List<Medico> medicos) {
        this.medicos = medicos;
    }
}
