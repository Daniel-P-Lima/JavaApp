import java.text.ParseException;
import java.util.*;
import java.text.SimpleDateFormat;

public class Consulta {
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    private String data;
    private String horario;
    private Medico medico;
    private Paciente paciente;

    public Consulta(String data, String horario, Medico medico, Paciente paciente) {
        this.data = data;
        this.horario = horario;
        this.medico = medico;
        this.paciente = paciente;
    }

    public String getData() {
        return data;
    }

    public String getHorario() {
        return horario;
    }

    public Medico getMedico() {
        return medico;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public static List<Consulta> criarConsultas(List<List<String>> dadosConsultas, List<Medico> medicos, List<Paciente> pacientes) {
        List<Consulta> consultas = new ArrayList<>();
        for (List<String> linha : dadosConsultas) {
            String data = linha.get(0);
            String horario = linha.get(1);
            String codigoUnicoMedico = linha.get(2);
            String cpfPaciente = linha.get(3);
            Medico medico = encontrarMedicoPorCodigoUnico(medicos, codigoUnicoMedico);
            Paciente paciente = encontrarPacientePorCpf(pacientes, cpfPaciente);
            if (medico != null && paciente != null) {
                consultas.add(new Consulta(data, horario, medico, paciente));
            }


        }
        return consultas;
    }

    private static Medico encontrarMedicoPorCodigoUnico(List<Medico> medicos, String codigoUnico) {
        for (Medico medico : medicos) {
            if (medico.getCodigoUnico().equals(codigoUnico)) {
                return medico;
            }
        }
        return null;
    }

    private static Paciente encontrarPacientePorCpf(List<Paciente> pacientes, String cpf) {
        for (Paciente paciente : pacientes) {
            if (paciente.getCpf().equals(cpf)) {
                return paciente;
            }
        }
        return null;
    }

    public static List<Consulta> consultasDoMedicoNoPeriodo(Medico medico, List<Consulta> consultas, String dataInicial, String dataFinal) {
        List<Consulta> consultasNoPeriodo = new ArrayList<>();
        for (Consulta consulta : consultas) {
            if (consulta.getMedico().equals(medico) && consulta.estaNoPeriodo(dataInicial, dataFinal)) {
                consultasNoPeriodo.add(consulta);
            }
        }
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        consultasNoPeriodo.sort(
                Comparator.comparing((Consulta c) -> {
                    try {
                        Date data = sdf.parse(c.getData());
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(data);
                        return calendar.get(Calendar.MONTH);
                    } catch (ParseException e) {
                        throw new IllegalArgumentException("Erro ao processar a data da consulta", e);
                    }
                }).reversed()
        );

        return consultasNoPeriodo;
    }

    private boolean estaNoPeriodo(String dataInicial, String dataFinal) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date dataIni = sdf.parse(dataInicial);
            Date dataFin = sdf.parse(dataFinal);
            Date data = sdf.parse(this.data);
            return data.compareTo(dataIni) >= 0 && data.compareTo(dataFin) <= 0;
        } catch (ParseException e) {
            throw new IllegalArgumentException("Erro ao processar a data do período", e);
        }
    }

    @Override
    public String toString() {
        return "Data: " + getData() + ", Horário: " + getHorario() + ", Médico: " + getMedico().getNome() + ", Paciente: " + getPaciente().getNome();
    }

}
