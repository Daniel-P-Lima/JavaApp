import javax.swing.*;
import java.awt.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.text.SimpleDateFormat;
import java.util.List;

public class Menu extends JFrame {
    private JTextField codigoMedicoField;
    private JTextArea outputArea;
    private List<Medico> medicos;
    private List<Paciente> pacientes;
    private List<Consulta> consultas;
    private JTextField dataInicialField;
    private JTextField dataFinalField;
    private JTextField cpfPacienteField;
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");


    public Menu(List<Medico> medicos, List<Paciente> pacientes, List<Consulta> consultas) {
        this.medicos = medicos;
        this.consultas = consultas;
        this.pacientes = pacientes;


        setTitle("Consultório Médico");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // campos de entrada e saída do formulario
        codigoMedicoField = new JTextField(20);
        outputArea = new JTextArea(20, 60);
        outputArea.setEditable(false);
        dataInicialField = new JTextField(10); // Inicializando dataInicial
        dataFinalField = new JTextField(10);
        cpfPacienteField = new JTextField(20);

        // botões
        JButton btnExibirPacientes = new JButton("Exibir Pacientes do Médico");
        btnExibirPacientes.addActionListener(e -> exibirPacientesDoMedico());

        JButton btnExibirConsultasDatas = new JButton("Exibir Consultas nas Datas");
        btnExibirConsultasDatas.addActionListener(e -> consultasDoMedicoNoPeriodo());

        JButton btnConsultasDeUmPaciente = new JButton("Exibir todas as consultas de um Paciente:");
        btnConsultasDeUmPaciente.addActionListener(e -> exibirConsultasDePaciente());

        setLayout(new FlowLayout());

        // Adiciona os componentes ao frame
        add(new JLabel("Código do Médico:"));
        add(codigoMedicoField);
        add(btnExibirPacientes);
        add(btnExibirConsultasDatas);
        add(new JLabel("Data Inicial (dd/MM/yyyy):"));
        add(dataInicialField);
        add(new JLabel("Data Final (dd/MM/yyyy):"));
        add(dataFinalField);
        add(new JLabel("CPF do Paciente:"));
        add(cpfPacienteField);
        add(btnConsultasDeUmPaciente);

        add(new JScrollPane(outputArea));
    }

    private void exibirPacientesDoMedico() {
        String codigoMedico = codigoMedicoField.getText();
        String resultado = Controller.exibirPacientesDoMedico(codigoMedico, medicos, consultas);
        outputArea.setText(resultado);
    }

    //2. Buscar consultas agendadas para um médico dentro de um período

    private void consultasDoMedicoNoPeriodo() {
        String codigoMedico = codigoMedicoField.getText();
        String dataInicialText = dataInicialField.getText();
        String dataFinalText = dataFinalField.getText();

        try {

            Date dataInicio = sdf.parse(dataInicialText);
            Date dataFim = sdf.parse(dataFinalText);

            Medico medico = Controller.encontrarMedicoPorCodigoUnico(medicos, codigoMedico);

            if (medico != null) {

                List<Consulta> consultasNoPeriodo = Controller.consultasDoMedicoNoPeriodo(medico, consultas, dataInicio, dataFim);

                
                consultasNoPeriodo.sort(
                        Comparator.comparing((Consulta consulta) -> {
                            try {
                                Date data = sdf.parse(consulta.getData());
                                Calendar calendar = Calendar.getInstance();
                                calendar.setTime(data);
                                return calendar.get(Calendar.MONTH);
                            } catch (ParseException e) {
                                throw new IllegalArgumentException("Erro ao processar a data da consulta", e);
                            }
                        })
                );

                StringBuilder resultado = new StringBuilder();
                for (Consulta consulta : consultasNoPeriodo) {
                    resultado.append(consulta.toString()).append("\n");
                }

                if (resultado.length() == 0) {
                    resultado.append("Nenhuma consulta encontrada para o período especificado.");
                }

                outputArea.setText(resultado.toString());
            } else {
                JOptionPane.showMessageDialog(this, "Médico não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Formato de data inválido. Por favor, use dd/MM/yyyy.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao buscar consultas. Verifique os dados inseridos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }



    //.5 Quais são todas as consultas agendadas que um determinado paciente possui?
    private void exibirConsultasDePaciente() {
        String cpfPaciente = cpfPacienteField.getText();

        Paciente pacienteAgendado = Controller.encontrarPacientePorCpf(pacientes, cpfPaciente);
        if (pacienteAgendado != null) {
            Date dataAtual = new Date();
            List<Consulta> consultasDoPaciente = Controller.consultasDoPacienteAgendadas(pacienteAgendado, consultas, dataAtual);

            StringBuilder resultado = new StringBuilder();
            if (!consultasDoPaciente.isEmpty()) {
                resultado.append("Consultas agendadas para o paciente ").append(pacienteAgendado.getNome()).append(":\n");
                for (Consulta consulta : consultasDoPaciente) {
                    resultado.append("Data: ").append(consulta.getData()).append(", Horário: ").append(consulta.getHorario())
                            .append(", Médico: ").append(consulta.getMedico().getNome()).append("\n");
                }
            } else {
                resultado.append("O paciente ").append(pacienteAgendado.getNome()).append(" não possui consultas agendadas.");
            }

            outputArea.setText(resultado.toString());
        } else {
            JOptionPane.showMessageDialog(this, "Paciente não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }







    public static void main(String[] args) {
        List<List<String>> dadosMedicos = LeituraMedicos.lerDados("Arquivos/medicos.csv");
        List<List<String>> dadosPacientes = LeituraPacientes.lerDados("Arquivos/pacientes.csv");
        List<List<String>> dadosConsultas = LeituraConsultas.lerDados("Arquivos/consultas.csv");

        List<Medico> medicos = Medico.criarMedicos(dadosMedicos);

        List<Paciente> pacientes = Paciente.criarPacientes(dadosPacientes);

        List<Consulta> consultas = Consulta.criarConsultas(dadosConsultas, medicos, pacientes);

        SwingUtilities.invokeLater(() -> {
            Menu menu = new Menu(medicos, pacientes, consultas);
            menu.setVisible(true);
        });
    }
}
